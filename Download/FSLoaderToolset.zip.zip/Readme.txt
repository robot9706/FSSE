Version: v0.2

FSModTool: https://github.com/robot9706/FSSE/wiki/FSModTool-guide

Setup:
1) Goto https://www.nexusmods.com/falloutshelter/mods/2/?tab=2&navtag=https%3A%2F%2Fwww.nexusmods.com%2Ffalloutshelter%2Fajax%2Fmodfiles%2F%3Fid%3D2&pUp=1
2) Download "Mod installer"
3) Extract the zip contents into a folder
4) Copy the mod tool exes to the folder (where the installer is extracted)